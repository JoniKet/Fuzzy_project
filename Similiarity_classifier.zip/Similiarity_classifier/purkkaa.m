function val = purkkaa(w, y)


val=1-calcfitness(y{2}, ideals{3}, y{1}, w);